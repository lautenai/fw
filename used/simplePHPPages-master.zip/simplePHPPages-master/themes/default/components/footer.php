<footer class="footer">
  <div class="container">
    <p>
      <?=$text ?>
    </p>
  </div>
</footer>
