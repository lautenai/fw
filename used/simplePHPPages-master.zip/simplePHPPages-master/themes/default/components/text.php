<section class="section is-medium">

	<div class="container">

		<h2 class="title"><?=$title ?></h2>

		<p><?=nl2br($text) ?></p>

	</div>

</section>
